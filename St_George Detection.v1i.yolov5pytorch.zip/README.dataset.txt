# St_George Detection > 2024-06-30 10:16am
https://universe.roboflow.com/bikram/st_george-detection

Provided by a Roboflow user
License: CC BY 4.0

